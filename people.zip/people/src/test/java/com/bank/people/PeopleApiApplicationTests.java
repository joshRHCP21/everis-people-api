package com.bank.people;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeopleApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
